import axios from 'axios';
import { Player } from '../types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const getLeaderboard = async (count = 10): Promise<Player[]> => {
  try {
    const response = await api.get(`/leaderboard?count=${count}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    throw error;
  }
};

export interface PlayerScoreData {
  id: string;
  name: string;
  score: number;
  avatar?: string;
}

export const addPlayerScore = async (playerData: PlayerScoreData): Promise<void> => {
  try {
    await api.post('/score', playerData);
  } catch (error) {
    console.error('Error adding player score:', error);
    throw error;
  }
};

export const updatePlayerScore = async (playerData: PlayerScoreData): Promise<void> => {
  try {
    await api.post('/score', playerData);
  } catch (error) {
    console.error('Error updating player score:', error);
    throw error;
  }
};

export const resetLeaderboard = async (): Promise<void> => {
  try {
    await api.post('/admin/reset');
  } catch (error) {
    console.error('Error resetting leaderboard:', error);
    throw error;
  }
};