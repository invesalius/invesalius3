import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Leaderboard from '../components/Leaderboard';
import PlayerForm from '../components/PlayerForm';
import ScoreUpdater from '../components/ScoreUpdater';
import AdminControls from '../components/AdminControls';
import { getLeaderboard } from '../services/api';
import { Player } from '../types';

const AdminPage: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      const data = await getLeaderboard();
      setPlayers(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching leaderboard:', err);
      setError('Failed to load leaderboard data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchLeaderboard();
  }, []);
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-gray-400">Loading admin panel...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-900/20 border border-red-700 rounded-lg p-6 text-center">
        <h2 className="text-xl font-bold text-red-400 mb-2">Error</h2>
        <p className="text-white">{error}</p>
        <button 
          onClick={() => fetchLeaderboard()}
          className="mt-4 btn btn-primary"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
          Admin Panel
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Manage players and scores in the leaderboard system
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Leaderboard initialPlayers={players} />
        </div>
        
        <div className="space-y-6">
          <PlayerForm onPlayerAdded={fetchLeaderboard} />
          <ScoreUpdater players={players} />
          <AdminControls onReset={fetchLeaderboard} />
        </div>
      </div>
    </motion.div>
  );
};

export default AdminPage;