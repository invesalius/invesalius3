import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { FaRandom } from 'react-icons/fa';
import { Player } from '../types';
import { updatePlayerScore } from '../services/api';

interface ScoreUpdateFormData {
  playerId: string;
  score: number;
}

interface ScoreUpdaterProps {
  players: Player[];
}

const ScoreUpdater: React.FC<ScoreUpdaterProps> = ({ players }) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  
  const { 
    register, 
    handleSubmit, 
    setValue,
    watch,
    formState: { errors } 
  } = useForm<ScoreUpdateFormData>({
    defaultValues: {
      playerId: players.length > 0 ? players[0].id : '',
      score: 100
    }
  });
  
  const selectedPlayerId = watch('playerId');
  const selectedPlayer = players.find(p => p.id === selectedPlayerId);
  
  const onSubmit = async (data: ScoreUpdateFormData) => {
    if (!selectedPlayer) return;
    
    setIsUpdating(true);
    setUpdateMessage(null);
    
    try {
      const newScore = selectedPlayer.score + data.score;
      
      await updatePlayerScore({
        id: selectedPlayer.id,
        name: selectedPlayer.name,
        score: newScore
      });
      
      setUpdateMessage({
        type: 'success',
        text: `Updated ${selectedPlayer.name}'s score to ${newScore.toLocaleString()}`
      });
      
      // Reset score input but keep player selected
      setValue('score', 100);
    } catch (error) {
      console.error('Error updating score:', error);
      setUpdateMessage({
        type: 'error',
        text: 'Failed to update score. Please try again.'
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const generateRandomScores = async () => {
    setIsUpdating(true);
    setUpdateMessage(null);
    
    try {
      const updates = players.map(async (player) => {
        // Random score between -500 and 1000
        const scoreChange = Math.floor(Math.random() * 1500) - 500;
        const newScore = Math.max(0, player.score + scoreChange);
        
        await updatePlayerScore({
          id: player.id,
          name: player.name,
          score: newScore
        });
        
        // Small delay between updates to see the animation effect
        return new Promise(resolve => setTimeout(resolve, 200));
      });
      
      await Promise.all(updates);
      
      setUpdateMessage({
        type: 'success',
        text: 'Random scores generated for all players'
      });
    } catch (error) {
      console.error('Error generating random scores:', error);
      setUpdateMessage({
        type: 'error',
        text: 'Failed to generate random scores. Please try again.'
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  if (players.length === 0) {
    return (
      <div className="card">
        <h2 className="text-xl font-bold mb-4">Update Scores</h2>
        <p className="text-gray-400">No players available. Add players first.</p>
      </div>
    );
  }
  
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">Update Scores</h2>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <label htmlFor="playerId" className="block text-sm font-medium mb-1">
            Select Player
          </label>
          <select
            id="playerId"
            className="input w-full"
            {...register('playerId', { required: 'Player is required' })}
          >
            {players.map(player => (
              <option key={player.id} value={player.id}>
                {player.name} (Current: {player.score.toLocaleString()})
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-6">
          <label htmlFor="score" className="block text-sm font-medium mb-1">
            Score Change
          </label>
          <div className="flex">
            <input
              id="score"
              type="number"
              className="input w-full"
              step={100}
              {...register('score', { 
                required: 'Score is required',
                valueAsNumber: true
              })}
            />
          </div>
          <p className="mt-1 text-sm text-gray-400">
            Use positive values to increase, negative to decrease
          </p>
          {errors.score && (
            <p className="mt-1 text-sm text-red-400">{errors.score.message}</p>
          )}
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="submit"
            disabled={isUpdating}
            className="btn btn-primary flex-1 flex items-center justify-center"
          >
            {isUpdating ? (
              <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></span>
            ) : null}
            Update Score
          </button>
          
          <button
            type="button"
            onClick={generateRandomScores}
            disabled={isUpdating}
            className="btn btn-secondary flex items-center justify-center"
          >
            <FaRandom className="mr-2" />
            Random Scores
          </button>
        </div>
      </form>
      
      {updateMessage && (
        <div className={`mt-4 p-3 rounded-lg ${
          updateMessage.type === 'success' ? 'bg-green-800/30 text-green-300' : 'bg-red-800/30 text-red-300'
        }`}>
          {updateMessage.text}
        </div>
      )}
    </div>
  );
};

export default ScoreUpdater;