import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaTrophy, FaMedal } from 'react-icons/fa';
import { Player } from '../types';
import { socket } from '../services/socket';

interface LeaderboardProps {
  initialPlayers?: Player[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ initialPlayers = [] }) => {
  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [updatedPlayerId, setUpdatedPlayerId] = useState<string | null>(null);
  
  useEffect(() => {
    // Listen for leaderboard updates from the server
    socket.on('leaderboard_update', (updatedPlayers: Player[]) => {
      // Find which player changed position or score
      const changedPlayer = updatedPlayers.find((newPlayer, index) => {
        const oldPlayer = players[index];
        return oldPlayer && (oldPlayer.id !== newPlayer.id || oldPlayer.score !== newPlayer.score);
      });
      
      if (changedPlayer) {
        setUpdatedPlayerId(changedPlayer.id);
        
        // Reset the highlight after animation completes
        setTimeout(() => {
          setUpdatedPlayerId(null);
        }, 2000);
      }
      
      setPlayers(updatedPlayers);
    });
    
    return () => {
      socket.off('leaderboard_update');
    };
  }, [players]);
  
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <FaTrophy className="text-amber-400" size={24} />;
      case 2:
        return <FaMedal className="text-gray-400" size={24} />;
      case 3:
        return <FaMedal className="text-amber-700" size={24} />;
      default:
        return <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center text-sm">{rank}</div>;
    }
  };
  
  return (
    <div className="card overflow-hidden">
      <h2 className="text-2xl font-bold mb-6 text-center bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
        Live Leaderboard
      </h2>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-700">
              <th className="px-4 py-3 text-left">Rank</th>
              <th className="px-4 py-3 text-left">Player</th>
              <th className="px-4 py-3 text-right">Score</th>
            </tr>
          </thead>
          <tbody>
            <AnimatePresence>
              {players.map((player) => (
                <motion.tr
                  key={player.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ 
                    opacity: 1, 
                    y: 0,
                    backgroundColor: updatedPlayerId === player.id 
                      ? ['rgba(124, 58, 237, 0.2)', 'rgba(124, 58, 237, 0)', 'rgba(124, 58, 237, 0.2)', 'rgba(124, 58, 237, 0)'] 
                      : 'transparent'
                  }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ 
                    duration: 0.3,
                    backgroundColor: { 
                      duration: 2,
                      times: [0, 0.3, 0.6, 1]
                    }
                  }}
                  className="border-b border-gray-700 hover:bg-gray-700/30 transition-colors"
                >
                  <td className="px-4 py-3 flex items-center">
                    {getRankIcon(player.rank)}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={player.avatar} 
                        alt={player.name}
                        className="w-8 h-8 rounded-full bg-gray-600"
                      />
                      <span>{player.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold">
                    <motion.span
                      key={`${player.id}-${player.score}`}
                      initial={{ opacity: 0, scale: 1.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={updatedPlayerId === player.id ? "text-purple-400" : ""}
                    >
                      {player.score.toLocaleString()}
                    </motion.span>
                  </td>
                </motion.tr>
              ))}
            </AnimatePresence>
            
            {players.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-8 text-center text-gray-400">
                  No players found. Add some players to see the leaderboard.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 text-sm text-gray-400 flex items-center justify-center">
        <div className="w-3 h-3 rounded-full bg-green-500 mr-2 animate-pulse"></div>
        Live updates enabled
      </div>
    </div>
  );
};

export default Leaderboard;