import React, { useState } from 'react';
import { FaSync } from 'react-icons/fa';
import { resetLeaderboard } from '../services/api';

interface AdminControlsProps {
  onReset?: () => void;
}

const AdminControls: React.FC<AdminControlsProps> = ({ onReset }) => {
  const [isResetting, setIsResetting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  
  const handleReset = async () => {
    if (!window.confirm('Are you sure you want to reset the leaderboard? This will replace all current data with sample data.')) {
      return;
    }
    
    setIsResetting(true);
    setMessage(null);
    
    try {
      await resetLeaderboard();
      
      setMessage({
        type: 'success',
        text: 'Leaderboard has been reset with sample data'
      });
      
      if (onReset) {
        onReset();
      }
    } catch (error) {
      console.error('Error resetting leaderboard:', error);
      setMessage({
        type: 'error',
        text: 'Failed to reset leaderboard. Please try again.'
      });
    } finally {
      setIsResetting(false);
    }
  };
  
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">Admin Controls</h2>
      
      <div className="space-y-4">
        <div>
          <button
            onClick={handleReset}
            disabled={isResetting}
            className="btn btn-secondary w-full flex items-center justify-center"
          >
            {isResetting ? (
              <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></span>
            ) : (
              <FaSync className="mr-2" />
            )}
            Reset Leaderboard
          </button>
          <p className="mt-1 text-sm text-gray-400">
            This will reset the leaderboard with sample data
          </p>
        </div>
        
        {message && (
          <div className={`p-3 rounded-lg ${
            message.type === 'success' ? 'bg-green-800/30 text-green-300' : 'bg-red-800/30 text-red-300'
          }`}>
            {message.text}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminControls;