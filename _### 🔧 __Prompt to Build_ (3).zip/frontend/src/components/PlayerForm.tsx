import React from 'react';
import { useForm } from 'react-hook-form';
import { FaPlus } from 'react-icons/fa';
import { addPlayerScore } from '../services/api';

interface PlayerFormData {
  name: string;
  score: number;
}

interface PlayerFormProps {
  onPlayerAdded?: () => void;
}

const PlayerForm: React.FC<PlayerFormProps> = ({ onPlayerAdded }) => {
  const { 
    register, 
    handleSubmit, 
    reset,
    formState: { errors, isSubmitting } 
  } = useForm<PlayerFormData>({
    defaultValues: {
      name: '',
      score: 1000
    }
  });
  
  const onSubmit = async (data: PlayerFormData) => {
    try {
      await addPlayerScore({
        id: Date.now().toString(),
        name: data.name,
        score: data.score
      });
      
      reset();
      
      if (onPlayerAdded) {
        onPlayerAdded();
      }
    } catch (error) {
      console.error('Error adding player:', error);
    }
  };
  
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">Add Player</h2>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <label htmlFor="name" className="block text-sm font-medium mb-1">
            Player Name
          </label>
          <input
            id="name"
            type="text"
            className="input w-full"
            placeholder="Enter player name"
            {...register('name', { required: 'Name is required' })}
          />
          {errors.name && (
            <p className="mt-1 text-sm text-red-400">{errors.name.message}</p>
          )}
        </div>
        
        <div className="mb-6">
          <label htmlFor="score" className="block text-sm font-medium mb-1">
            Initial Score
          </label>
          <input
            id="score"
            type="number"
            className="input w-full"
            min={0}
            step={100}
            {...register('score', { 
              required: 'Score is required',
              min: { value: 0, message: 'Score must be positive' },
              valueAsNumber: true
            })}
          />
          {errors.score && (
            <p className="mt-1 text-sm text-red-400">{errors.score.message}</p>
          )}
        </div>
        
        <button
          type="submit"
          disabled={isSubmitting}
          className="btn btn-primary w-full flex items-center justify-center"
        >
          {isSubmitting ? (
            <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></span>
          ) : (
            <FaPlus className="mr-2" />
          )}
          Add Player
        </button>
      </form>
    </div>
  );
};

export default PlayerForm;