import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaTrophy, FaUserCog } from 'react-icons/fa';

const Navbar: React.FC = () => {
  const location = useLocation();
  
  return (
    <nav className="bg-gray-800 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="flex items-center space-x-2">
            <FaTrophy className="text-amber-400 text-2xl" />
            <span className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              Real-Time Leaderboard
            </span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <Link 
              to="/" 
              className={`px-3 py-2 rounded-lg transition-colors ${
                location.pathname === '/' 
                  ? 'bg-purple-600 text-white' 
                  : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              Leaderboard
            </Link>
            <Link 
              to="/admin" 
              className={`px-3 py-2 rounded-lg transition-colors flex items-center space-x-1 ${
                location.pathname === '/admin' 
                  ? 'bg-pink-600 text-white' 
                  : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <FaUserCog />
              <span>Admin</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;