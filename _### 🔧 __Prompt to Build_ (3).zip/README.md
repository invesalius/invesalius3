# Real-Time Leaderboard Application

A full-stack, real-time leaderboard web application that displays live player scores and rankings.

## Tech Stack

- **Backend**: Node.js with Express.js
- **Real-time Communication**: Socket.io
- **Data Store**: Redis (using sorted sets)
- **Frontend**: React with TypeScript and Tailwind CSS

## Features

- Live scoreboard showing top players, sorted by highest scores
- Real-time updates without refresh whenever scores change
- Responsive layout for mobile and desktop
- Player management via admin panel
- WebSocket integration for instant updates
- Redis sorted sets for efficient ranking

## Running Locally

### Using Docker Compose (Recommended)

1. Make sure you have Docker and Docker Compose installed
2. Clone this repository
3. Run the application: