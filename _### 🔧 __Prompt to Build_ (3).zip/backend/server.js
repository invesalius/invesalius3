require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const Redis = require('ioredis');
const cors = require('cors');

// Initialize Express app
const app = express();
const server = http.createServer(app);

// Configure CORS
app.use(cors());
app.use(express.json());

// Initialize Redis client
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
const LEADERBOARD_KEY = 'leaderboard';

// Initialize Socket.io
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Socket.io connection handler
io.on('connection', (socket) => {
  console.log('New client connected');
  
  // Send current leaderboard to newly connected client
  getLeaderboard().then(leaderboard => {
    socket.emit('leaderboard_update', leaderboard);
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Helper function to get leaderboard data
async function getLeaderboard(count = 10) {
  try {
    // Get top players with scores using ZREVRANGE (highest scores first)
    const leaderboardData = await redis.zrevrange(LEADERBOARD_KEY, 0, count - 1, 'WITHSCORES');
    
    // Format the data into an array of objects
    const leaderboard = [];
    for (let i = 0; i < leaderboardData.length; i += 2) {
      const playerData = JSON.parse(leaderboardData[i]);
      leaderboard.push({
        id: playerData.id,
        name: playerData.name,
        avatar: playerData.avatar,
        score: parseInt(leaderboardData[i + 1]),
        rank: Math.floor(i / 2) + 1
      });
    }
    
    return leaderboard;
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return [];
  }
}

// API Routes
app.get('/api/leaderboard', async (req, res) => {
  try {
    const count = parseInt(req.query.count) || 10;
    const leaderboard = await getLeaderboard(count);
    res.json(leaderboard);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
});

app.post('/api/score', async (req, res) => {
  try {
    const { id, name, score, avatar } = req.body;
    
    if (!id || !name || score === undefined) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    const playerData = JSON.stringify({ id, name, avatar: avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${name}` });
    
    // Update player score in Redis sorted set
    await redis.zadd(LEADERBOARD_KEY, score, playerData);
    
    // Get updated leaderboard
    const updatedLeaderboard = await getLeaderboard();
    
    // Broadcast updated leaderboard to all connected clients
    io.emit('leaderboard_update', updatedLeaderboard);
    
    res.json({ success: true, player: { id, name, score } });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to update score' });
  }
});

// Initialize sample data
async function initSampleData() {
  try {
    const exists = await redis.exists(LEADERBOARD_KEY);
    
    if (!exists) {
      console.log('Initializing sample leaderboard data...');
      
      const samplePlayers = [
        { id: '1', name: 'Alex', score: 2500, avatar: null },
        { id: '2', name: 'Jordan', score: 3200, avatar: null },
        { id: '3', name: 'Taylor', score: 2800, avatar: null },
        { id: '4', name: 'Morgan', score: 4100, avatar: null },
        { id: '5', name: 'Casey', score: 3700, avatar: null },
        { id: '6', name: 'Riley', score: 2900, avatar: null },
        { id: '7', name: 'Quinn', score: 3500, avatar: null },
        { id: '8', name: 'Avery', score: 3100, avatar: null },
        { id: '9', name: 'Dakota', score: 2700, avatar: null },
        { id: '10', name: 'Skyler', score: 3900, avatar: null }
      ];
      
      for (const player of samplePlayers) {
        const playerData = JSON.stringify({
          id: player.id,
          name: player.name,
          avatar: player.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${player.name}`
        });
        
        await redis.zadd(LEADERBOARD_KEY, player.score, playerData);
      }
      
      console.log('Sample data initialized');
    }
  } catch (error) {
    console.error('Error initializing sample data:', error);
  }
}

// Admin route to reset leaderboard
app.post('/api/admin/reset', async (req, res) => {
  try {
    await redis.del(LEADERBOARD_KEY);
    await initSampleData();
    
    const updatedLeaderboard = await getLeaderboard();
    io.emit('leaderboard_update', updatedLeaderboard);
    
    res.json({ success: true, message: 'Leaderboard reset with sample data' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to reset leaderboard' });
  }
});

// Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  await initSampleData();
});